package com.example.heb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HebApplicationTests {

    @Test
    void contextLoads() {
    }

}
