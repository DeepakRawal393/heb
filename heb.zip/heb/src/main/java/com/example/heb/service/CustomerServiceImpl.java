package com.example.heb.service;

import com.example.heb.repository.CustomerRepository;
import com.example.heb.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;


public class CustomerServiceImpl implements CustomerService{
    @Autowired
    private CustomerRepository repository;

    public List<Customer> getAllCustomers() {
        return repository.findAll();
    }

    public List<Customer> getCustomersByCity(String city) {
        return repository.findByCity(city);
    }

    public Customer getCustomerById(Long id) {
        return repository.findById(id).orElse(null);
    }

    public Customer saveCustomer(Customer customer) {
        return repository.save(customer);
    }
}
