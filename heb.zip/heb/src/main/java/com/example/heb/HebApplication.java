package com.example.heb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HebApplication {

    public static void main(String[] args) {
        SpringApplication.run(HebApplication.class, args);
    }

}
