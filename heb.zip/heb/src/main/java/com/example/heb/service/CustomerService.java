package com.example.heb.service;

import com.example.heb.model.Customer;

import java.util.List;

public interface CustomerService {



    public List<Customer> getAllCustomers() ;


    public List<Customer> getCustomersByCity(String city) ;

    public Customer getCustomerById(Long id) ;

    public Customer saveCustomer(Customer customer) ;
}
