package com.example.heb.repository;


import com.example.heb.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
    // You can add custom query methods here if needed
    List<Customer> findByCity(String city);
}
